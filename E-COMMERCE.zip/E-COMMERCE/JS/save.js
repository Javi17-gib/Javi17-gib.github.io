window.addEventListener("load", function(){
    document.getElementById("btnsave").addEventListener("click",function(){
        alert("Productos Guardados Exitosamente")
    })
})

window.addEventListener("load", function(){
    document.getElementById("btnAgregarr").addEventListener("click",function(){
        alert("Favor de llenar los campos")
    })
})