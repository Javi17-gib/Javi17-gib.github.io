<aside class="d-flex" style="width: 15%;">
        <div class="bg-dark text-white p-2 w-100" style="min-height: 100vh">
            <h2 class="text-center"> <i class="ri-store-3-fill" style="font-size: 60px;"></i> <br>E-COMMERCE</h2>
            <nav>
                <ul class="nav flex-column">
                    <li class="nav-item"><a href="../admin/Admin.php" class="nav-link text-white"><i
                                class="bi bi-house-fill"></i>&nbsp;&nbsp;&nbsp;Inicio</a></li>
                    <li class="nav-item"><a href="../users/User.php" class="nav-link text-white"><i
                                class="bi bi-person-fill"></i>&nbsp;&nbsp;&nbsp;Usuarios</a></li>
                    <li class="nav-item"><a href="../PRODUCTOS/Productos.php" class="nav-link text-white"><i
                                class="bi bi-bag-check-fill"></i>&nbsp;&nbsp;&nbsp;Productos</a></li>
                    <li class="nav-item"><a href="../stock/stock.php" class="nav-link text-white"><i
                                class="bi bi-bag-check-fill"></i>&nbsp;&nbsp;&nbsp;Stock</a></li>
                    <li class="nav-item"><a href="../envios/envios.php" class="nav-link text-white"><i
                                class="bi bi-airplane-fill"></i>&nbsp;&nbsp;&nbsp;Envios</a></li>
                    <li class="nav-item"><a href="../comentarios/comentarios.php" class="nav-link text-white"><i
                                class="bi bi-chat-left-text-fill"></i>&nbsp;&nbsp;&nbsp;Comentarios</a></li>
                    <li class="nav-item"><a href="../pedidos/pedidos.php" class="nav-link text-white"><i
                                class="bi bi-card-checklist"></i>&nbsp;&nbsp;&nbsp;Pedidos</a></li>
                    <li class="nav-item"><a href="../Proveedor/proveedor.php" class="nav-link text-white"><i
                                class="bi bi-archive-fill"></i>&nbsp;&nbsp;&nbsp;Proveedor</a></li>
                  
                </ul>
            </nav>
        </div>
    </aside>